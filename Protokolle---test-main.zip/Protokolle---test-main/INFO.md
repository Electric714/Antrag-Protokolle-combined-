# Privacy Policy for Protokolle
Protokolle does not collect, store, or share any personal data. All processing happens entirely on your device.