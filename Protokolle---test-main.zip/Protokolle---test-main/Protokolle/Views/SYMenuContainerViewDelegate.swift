//
//  SYContainerViewDelegate.swift
//  syslog
//
//  Created by samara on 20.05.2025.
//

// MARK: - Protocal
protocol SYMenuContainerViewDelegate {
	func handleMenuToggle()
}
