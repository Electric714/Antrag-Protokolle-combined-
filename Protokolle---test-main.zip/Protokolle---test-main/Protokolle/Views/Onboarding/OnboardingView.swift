//
//  OnboardingView.swift
//  Protokolle
//
//  Created by samara on 27.05.2025.
//
